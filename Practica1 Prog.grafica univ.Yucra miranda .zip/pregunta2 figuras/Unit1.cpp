#include <vcl.h>              // Librer�a necesaria para trabajar con la VCL (Visual Component Library)
#include <vector>             // Para usar el contenedor vector de la STL
#include <math.h>             // Para funciones matem�ticas como coseno, seno y PI
#include <algorithm>          // Para usar funciones como max()
#pragma hdrstop
#include "Unit1.h"            // Archivo de encabezado de la unidad
#pragma package(smart_init)
#pragma resource "*.dfm"      // Carga los recursos visuales del formulario

TForm1 *Form1;                // Instancia del formulario principal

//---------------------------------------------------------------------------
// Constructor del formulario, se ejecuta al iniciar la aplicaci�n
__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}

//---------------------------------------------------------------------------
// Esta funci�n sirve para redondear valores flotantes a enteros de forma manual,
// ya que C++ Builder puede no tener la funci�n round() habilitada por defecto.
inline int roundFloat(float val) {
    return (int)(val + 0.5f);
}

//---------------------------------------------------------------------------
// Estructura para representar un punto en el plano cartesiano con coordenadas X y Y.
struct Punto {
    int x, y;
};

//---------------------------------------------------------------------------
// Funci�n para dibujar una l�nea entre dos puntos usando el algoritmo DDA.
// Este algoritmo calcula puntos intermedios entre dos coordenadas y dibuja p�xel por p�xel.
void DDA_Centro(TCanvas* canvas, int x1, int y1, int x2, int y2, int cx, int cy) {
    int dx = x2 - x1;
    int dy = y2 - y1;
    int pasos = std::max(abs(dx), abs(dy));  // Elegimos el n�mero de pasos con base en la mayor distancia

    float incX = dx / (float)pasos;  // Determina cu�nto se incrementa X por paso
    float incY = dy / (float)pasos;  // Determina cu�nto se incrementa Y por paso

    float x = x1;
    float y = y1;

    // Dibuja p�xel por p�xel la l�nea, centrando los valores respecto al centro de la pantalla
    for (int i = 0; i <= pasos; i++) {
        int px = cx + roundFloat(x);   // Se suma el centro en X
        int py = cy - roundFloat(y);   // Se invierte Y y se suma el centro en Y (por c�mo funciona el sistema de coordenadas en pantalla)
        canvas->Pixels[px][py] = clRed;  // Pinta el p�xel de color rojo
        x += incX;
        y += incY;
    }
}

//---------------------------------------------------------------------------
// Dibuja un pol�gono regular con un n�mero de lados y radio determinados,
// y lo centra en (cxPantalla, cyPantalla).
void DibujarPoligono(TCanvas* canvas, int lados, int radio, int cxPantalla, int cyPantalla) {
    // �ngulo entre cada v�rtice
    double anguloPaso = 2 * M_PI / lados;
    // Inicia en la parte superior, ajustado para que un lado quede alineado horizontalmente
    double anguloInicial = -M_PI / 2 + anguloPaso / 2;

    std::vector<Punto> puntos;  // Vector que almacenar� los v�rtices del pol�gono

    // Calculamos cada punto del pol�gono
    for (int i = 0; i < lados; i++) {
        double angulo = anguloInicial + i * anguloPaso;
        int x = (int)(radio * cos(angulo));  // Coordenada X usando coseno
        int y = (int)(radio * sin(angulo));  // Coordenada Y usando seno

        Punto p;
        p.x = x;
        p.y = y;
        puntos.push_back(p);  // Guardamos el punto
    }

    // Unimos cada punto con el siguiente para formar el contorno del pol�gono
    for (int i = 0; i < lados; i++) {
        Punto p1 = puntos[i];
        Punto p2 = puntos[(i + 1) % lados];  // El �ltimo punto se conecta con el primero
        DDA_Centro(canvas, p1.x, p1.y, p2.x, p2.y, cxPantalla, cyPantalla);
    }
}

//---------------------------------------------------------------------------
// Evento que se dispara cuando se hace clic en el bot�n 1.
// Dibuja varios pol�gonos conc�ntricos con n�mero de lados creciente (de 3 a 10).
void __fastcall TForm1::Button1Click(TObject *Sender)
{
    // Se limpia el fondo y se pinta de blanco
    Canvas->Brush->Color = clWhite;
    Canvas->FillRect(ClientRect);

    // Se calcula el centro de la pantalla
    int cxPantalla = ClientWidth / 2;
    int cyPantalla = ClientHeight / 2;

    // Par�metros para controlar la cantidad de figuras, su tama�o inicial y c�mo crecer�n
    int cantidadFiguras = 8;
    int radioInicial = 30;
    int incrementoRadio = 20;

    // Dibuja cada pol�gono, aumentando lados y radio progresivamente
    for (int i = 0; i < cantidadFiguras; i++) {
        int lados = 3 + i;
        int radio = radioInicial + i * incrementoRadio;
        DibujarPoligono(Canvas, lados, radio, cxPantalla, cyPantalla);
    }
}

//---------------------------------------------------------------------------
// Esta funci�n es para crear una figura tipo "telara�a" formada por hex�gonos conc�ntricos,
// conectados con l�neas radiales.
void DibujarHexaTelarana(TCanvas* canvas, int niveles, int radioPaso, int cxPantalla, int cyPantalla) {
    const int lados = 6;  // Un hex�gono tiene 6 lados
    double anguloPasoHex = 2 * M_PI / lados;

    std::vector< std::vector<Punto> > capas;  // Este vector almacenar� cada "anillo" de hex�gonos

    // Generamos los puntos de cada capa
    for (int nivel = 1; nivel <= niveles; ++nivel) {
        int radio = nivel * radioPaso;
        std::vector<Punto> capa;

        // Se calculan los 6 v�rtices del hex�gono actual
        for (int i = 0; i < lados; ++i) {
            double angulo = 0 + i * anguloPasoHex;  // Ajustamos para empezar desde arriba
            int x = (int)(radio * cos(angulo));
            int y = (int)(radio * sin(angulo));
            Punto p;
            p.x = x;
            p.y = y;
            capa.push_back(p);
        }

        capas.push_back(capa);  // Agregamos esta capa al conjunto de capas
    }

    // Dibujamos los contornos de cada hex�gono
    for (int k = 0; k < (int)capas.size(); ++k) {
        for (int i = 0; i < lados; ++i) {
            Punto p1 = capas[k][i];
            Punto p2 = capas[k][(i + 1) % lados];  // El �ltimo se conecta con el primero
            DDA_Centro(canvas, p1.x, p1.y, p2.x, p2.y, cxPantalla, cyPantalla);
        }
    }

    // Ahora se dibujan las l�neas que van desde el centro hacia afuera en cada v�rtice
    for (int i = 0; i < lados; ++i) {
        for (int nivel = 0; nivel < (int)capas.size() - 1; ++nivel) {
            Punto p1 = capas[nivel][i];
            Punto p2 = capas[nivel + 1][i];
            DDA_Centro(canvas, p1.x, p1.y, p2.x, p2.y, cxPantalla, cyPantalla);
        }
    }
}

//---------------------------------------------------------------------------
// Evento del bot�n 2 que al presionarse dibuja una telara�a hexagonal conc�ntrica.
void __fastcall TForm1::Button2Click(TObject *Sender)
{
    // Se limpia el lienzo de dibujo
    Canvas->Brush->Color = clWhite;
    Canvas->FillRect(ClientRect);

    // Se calcula el centro del �rea visible del formulario
    int cxPantalla = ClientWidth / 2;
    int cyPantalla = ClientHeight / 2;

    int niveles = 6;         // Cantidad de anillos o capas hexagonales que se dibujar�n
    int radioPaso = 20;      // Distancia entre cada capa

    // Llamamos a la funci�n que dibuja la figura
    DibujarHexaTelarana(Canvas, niveles, radioPaso, cxPantalla, cyPantalla);
}

