#include <vcl.h>
#pragma hdrstop
#include <math.h>
#include "Unit1.h"
//-----------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;

struct tmat {
    double v[3][3];
};

struct tpunto {
    double x, y;
};

// Definir la matriz identidad
tmat identidad = {{{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}};
tpunto punto1 = {0, 1};
tpunto punto2 = {2, 2};
tmat mat = identidad;

// Funci�n para aplicar una matriz a un punto
void aplica(tmat *m, tpunto a, tpunto *b) {
    b->x = m->v[0][0] * a.x + m->v[0][1] * a.y + m->v[0][2];
    b->y = m->v[1][0] * a.x + m->v[1][1] * a.y + m->v[1][2];
}
void multiplica(tmat *a, tmat *b, tmat *c) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            c->v[i][j] = 0;
            for (int k = 0; k < 3; k++) {
                c->v[i][j] += a->v[i][k] * b->v[k][j];
            }
        }
    }
}
void trasladar(double tx, double ty) {
    tmat a, b;
    a = identidad;
    a.v[0][2] = tx;
    a.v[1][2] = ty;
    b = mat;
    multiplica(&a, &b, &mat);
}
void escalar(double sx, double sy) {
    tmat a, b;
    a = identidad;
    a.v[0][0] = sx;
    a.v[1][1] = sy;
    b = mat;
    multiplica(&a, &b, &mat);
}
void rotar(double ang) {
    double dcos = cos(ang * M_PI / 180);
    double dsin = sin(ang * M_PI / 180);
    tmat a, b;
    a = identidad;
    a.v[0][0] = dcos;
    a.v[0][1] = -dsin;
    a.v[1][0] = dsin;
    a.v[1][1] = dcos;
    b = mat;
    multiplica(&a, &b, &mat);
}
void reflejarX() {
    tmat a, b;
    a = identidad;
    a.v[1][1] = -1;
    b = mat;
    multiplica(&a, &b, &mat);
}
void reflejarY() {
    tmat a, b;
    a = identidad;
    a.v[0][0] = -1;
    b = mat;
    multiplica(&a, &b, &mat);
}
void dibujar() {
    int maxx = Form1->Image1->Width;
    int maxy = Form1->Image1->Height;

    // Limpiar el �rea de dibujo (reiniciar el lienzo)
    Form1->Image1->Canvas->Brush->Color = clWhite;
    Form1->Image1->Canvas->FillRect(Rect(0, 0, maxx, maxy));
    // Dibujar los ejes
    Form1->Image1->Canvas->Pen->Color = clRed;
    Form1->Image1->Canvas->MoveTo(0, maxy / 2);
    Form1->Image1->Canvas->LineTo(maxx, maxy / 2);
    Form1->Image1->Canvas->MoveTo(maxx / 2, 0);
    Form1->Image1->Canvas->LineTo(maxx / 2, maxy);

    // Dibujar la l�nea original entre (0,1) y (2,2)
    tpunto p1, p2;
    aplica(&mat, punto1, &p1);
    aplica(&mat, punto2, &p2);

    Form1->Image1->Canvas->Pen->Color = clBlack;
    Form1->Image1->Canvas->MoveTo(maxx / 2 + p1.x * 20, maxy / 2 - p1.y * 20);
    Form1->Image1->Canvas->LineTo(maxx / 2 + p2.x * 20, maxy / 2 - p2.y * 20);
}


// Funci�n para resetear las transformaciones
void resetear() {
    mat = identidad;
}

//-----------------------------------------------------------------------

__fastcall TForm1::TForm1(TComponent* Owner)
        : TForm(Owner)
{
}

//-----------------------------------------------------------------------

void __fastcall TForm1::Button1Click(TObject *Sender)
{
    dibujar();
}
//-----------------------------------------------------------------------

void __fastcall TForm1::Button2Click(TObject *Sender)
{
    rotar(45);
    trasladar(3, 0);
    rotar(15);
    dibujar();
}
//-----------------------------------------------------------------------

void __fastcall TForm1::Button3Click(TObject *Sender)
{
    trasladar(0, -3);
    reflejarY();
    dibujar();
}
//-----------------------------------------------------------------------

void __fastcall TForm1::Button4Click(TObject *Sender)
{
    rotar(15);
    reflejarX();
    dibujar();
}
//-----------------------------------------------------------------------

void __fastcall TForm1::Button5Click(TObject *Sender)
{
    escalar(3, 3);
    trasladar(2, 4);
    dibujar();
}
//-----------------------------------------------------------------------

void __fastcall TForm1::Button6Click(TObject *Sender)
{
    resetear();
    dibujar();
}
//-----------------------------------------------------------------------

void __fastcall TForm1::Button7Click(TObject *Sender)
{
    Application->Terminate();
}
//-----------------------------------------------------------------------

